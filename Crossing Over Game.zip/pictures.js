//imagens e sons do jogo

let imagemDaEstrada;
let imagemDoAtor;
let imagemCarro;
let imagemCarro2;
let imagemCarro3;

//sons do jogo
let somDaTrilha;
let somDaColisao;
let somDoPonto;

function preload(){
 imagemDaEstrada = loadImage("Pictures/Road.png");
 imagemDoAtor = loadImage("Pictures/Character.gif");
 imagemCarro = loadImage("Pictures/Car-1.png");
 imagemCarro2 = loadImage("Pictures/Car-2.png");
 imagemCarro3 = loadImage("Pictures/Car-3.png");
  imagemCarros = [imagemCarro, imagemCarro2, imagemCarro3, imagemCarro, imagemCarro2, imagemCarro3];


somDaTrilha = loadSound("sounds/trilha.mp3");
somDaColisao = loadSound("sounds/colidiu.wav");
somDoPonto = loadSound("sounds/pontos.wav");
}